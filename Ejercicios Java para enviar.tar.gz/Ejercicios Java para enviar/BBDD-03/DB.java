import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

class DB {
    String url = null; // URL de conexión
    String usuario = null; //  usuario de MySQL
    String password = null; //  contraseña de MySQL

    Connection conexion=null;
    Statement sentencia=null;
    ResultSet resultado=null;

    static int numResp=0;

    DB(String url, String usuario, String password){
        this.url=url;
        this.usuario=usuario;
        this.password=password;
        sentencia=conectar();
        if (sentencia==null)
            return;
      
    }
    Statement conectar(){
        Statement sentencia=null;
        try {
            //1.- Cargar el driver JDBC para MySQL que está en mysql-connector-j-9.1.0.jar
            Class.forName("com.mysql.cj.jdbc.Driver");

            //2.- Establecer la conexión
            // Conecta al servidor MySQL. La URL no incluye el nombre de una base de datos específica, 
            // ya que queremos listar todas las bases de datos.
            conexion = DriverManager.getConnection(url,usuario,password);

            //3.- Crea un objeto Statement para ejecutar consultas SQL
            sentencia = conexion.createStatement();
            return sentencia;
        } catch (ClassNotFoundException e) {
            System.err.println("Error: No se pudo cargar el controlador JDBC: " + e.getMessage());
            return null;
        }catch(SQLException e ){
            System.err.println("Otro error JDBC: " + e.getMessage());
            return null;
        }
    }


    
    String resultSetToHtmlTable(ResultSet rs) throws SQLException {
        StringBuilder htmlTable = new StringBuilder();
        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();

        // Inicio de la tabla HTML
        htmlTable.append("<table border='1'>\n");

        // Encabezados de la tabla
        htmlTable.append("<tr>");
        for (int i = 1; i <= columnCount; i++) {
            htmlTable.append("<th>")
                        .append(metaData.getColumnName(i))
                        .append("</th>");
        }
        htmlTable.append("</tr>\n");

        // Filas con datos
        while (rs.next()) {
            htmlTable.append("<tr>");
            for (int i = 1; i <= columnCount; i++) {
                htmlTable.append("<td>")
                            .append(rs.getObject(i) != null ? rs.getObject(i).toString() : "")
                            .append("</td>");
            }
            htmlTable.append("</tr>\n");
        }

        // Cierre de la tabla
        htmlTable.append("</table>");
        
        return htmlTable.toString();
    }
    
    void guardarHTMLEnFichero(String contenido) {
        String nombreFichero= "respuesta"+(numResp++)+".html";
        nombreFichero="C:\\Java_proyectos\\raizWeb\\temp\\"+nombreFichero;
        
        try (FileWriter writer = new FileWriter(nombreFichero)) {
            writer.write(contenido);
            System.out.println("El HTML generado se ha guardado en el fichero " + nombreFichero);
        } catch (IOException e) {
            System.err.println("Error al guardar el string en el fichero: " + e.getMessage());
        }
    }



   
    void ejecutarQuery(String query, List<String> cabecera) {
        String html="";
        try{
            System.out.println("\n Resultado de la consulta: \n"+ query);

            resultado = sentencia.executeQuery(query);
            html=resultSetToHtmlTable(resultado);
            System.out.println(html);
            guardarHTMLEnFichero( html);
            /* 
            String nombreColumna="";
            int registro=0;
            while (resultado.next()) {
                registro++;
                System.out.println("===============inicio del registro "+registro+" =========");
                for (int i = 0; i < cabecera.size(); i++) {
                    nombreColumna = cabecera.get(i);
                    System.out.println(nombreColumna+ ":"+resultado.getString(i+1));
                    
                }
               
            }
                */



        } catch ( SQLException e) {
            System.err.println("Error de consulta a la Base de Datos: \n" + e.getMessage());
        }
    }

    // Cuando la consulta no trae cabeceras se la generamos
    void ejecutarQuery(String query) {
        List<String> cabeceras=new ArrayList();
        try{
            resultado = sentencia.executeQuery(query);
            ResultSetMetaData metaDatos = resultado.getMetaData();
            int numeroColumnas = metaDatos.getColumnCount();
            String nombreColumna="";

            // Se obtiene sólo los nombres de las columnas
            for (int i = 1; i <= numeroColumnas; i++) {
                nombreColumna = metaDatos.getColumnName(i);
                cabeceras.add(nombreColumna);
            }
            ejecutarQuery( query, cabeceras);


        } catch ( SQLException e) {
            System.err.println("Error de consulta a la Base de Datos: \n" + e.getMessage());
        }
    }
    

void cerrar(){

    try{
        // Cerrar la conexión y los recursos
        resultado.close();
        sentencia.close();
        conexion.close();

    }catch ( SQLException e) {
        System.err.println("Error: " + e.getMessage());
    }

}

}
