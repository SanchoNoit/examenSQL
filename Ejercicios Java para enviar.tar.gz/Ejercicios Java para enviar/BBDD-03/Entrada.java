import java.util.List;
import java.util.Scanner;

public class Entrada {
    
    public static void main(String[] args) {
       
        // Se adapta la conexión al servidor MySQL del dominio de la promoción
        String url = "jdbc:mysql://dim47:3307/sanchezVentas"; // URL de conexión
        String usuario = "root"; //  usuario de MySQL
        String contraseña = "4321"; //  contraseña de MySQL
        String query="";
        DB db= new DB(url,usuario,contraseña);
        //db.conectar();
        Scanner scanner = new Scanner(System.in);
        int opcion=0;

        do {
            mostrarMenu(); // Mostramos el menú
            System.out.print("Elige una opción: ");
            try{opcion = scanner.nextInt();}catch(Exception e){opcion=0;}

            switch (opcion) {

                case 1:
                    query="SELECT\r\n" + //
                                                "    dp.Id_Pedido,\r\n" + //
                                                "    \r\n" + //
                                                "    ROUND(SUM(PrecioUnidad * Cantidad * (1 - Descuento)),2) AS Total\r\n" + //
                                                "FROM\r\n" + //
                                                "    detallespedidos dp\r\n" + //
                                                "GROUP BY\r\n" + //
                                                "    dp.Id_Pedido\r\n" + //
                                                "ORDER BY\r\n" + //
                                                "Id_Pedido";
                    db.ejecutarQuery(query);
                    pulsa_tecla();
                    break;
                case 2:
                    query="SELECT p.NombreProducto, p.Id_Categoria, p.PrecioUnidad\r\n" + //
                                                "                      FROM productos p\r\n" + //
                                                "                      WHERE Id_Categoria = (SELECT Id_Categoria\r\n" + //
                                                "                                            FROM categorias c\r\n" + //
                                                "                                            WHERE NombreCategoria = 'Lacteos');\r\n" + //
                                                "";
                    db.ejecutarQuery(query);
                    
                    pulsa_tecla();
                    break;
                case 3:
                    query="SELECT NombreProducto, CantidadPorUnidad,PrecioUnidad, UnidadesEnExistencia FROM productos";
                    List <String> cabeceras= List.of("Nombre", "UnidadesPorCaja", "Precio", "Stock");
                    db.ejecutarQuery(query, cabeceras);
                    pulsa_tecla();
                    break;
                case 4:
                    query="SELECT DISTINCT Pais FROM clientes";
                    db.ejecutarQuery(query);
                    pulsa_tecla();
                    break;
                case 5:
                    query="SELECT NOmbreCompania, ciudad  FROM clientes WHERE Pais='Espana'";
                    db.ejecutarQuery(query);
                    pulsa_tecla();
                    break;
                case 0:
                    db.cerrar();
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida.");
                    pulsa_tecla();
            }
        } while (opcion != 0); // Repetimos hasta que el usuario elija la opción 0

        scanner.close(); // Cerramos el scanner
    }


    public static void mostrarMenu() {
        System.out.println("\n--- Menú ---");
        System.out.println("1. (31) Devuelve el Id del pedido, el valor total del pedido redondeado a dos decimales ");
        System.out.println("2. (33) Nombre de producto, id de categoría y precio unidad de los productos cuya categoría es 'Lacteos' ");
        System.out.println("3. Nombre, UnidadesPorCaja, P y Stock de cada producto");
        System.out.println("4. Consulta que me diga los países en los cuales tengo clientes");
        System.out.println("5. Presentar  el nombre y la ciudad de mis clientes que son españoles.");
        
        System.out.println("0. Salir");
    }
    public static void pulsa_tecla(){
        System.out.println("Pulsa ENTER para continuar...");
        try{System.in.read(); // Espera a que el usuario presione una tecla
        }catch(Exception e){}
    }
}
