package es.mde;

import java.io.IOException;
import java.util.Scanner;

public class MenuPrincipal {

	public static void main(String[] args) {
		int opcionSeleccionada;
		Scanner in = new Scanner(System.in);
		String url = "jdbc:mysql://www.dim47.es:3307/"; // URL de conexión
		String usuario = "root"; // usuario de MySQL
		String contrasena = "4321"; // contraseña de MySQL

		do {
			mostrarMenu();
			try {
				opcionSeleccionada = in.nextInt();
			} catch (Exception e) {
				opcionSeleccionada = 0;
			}

			switch (opcionSeleccionada) {
				case 1:
					new InformacionServidor(url, usuario, contrasena);
					break;
				case 2:
					new ConsultasEjercicios(url, usuario, contrasena);
					
			}
			System.out.println("--------------------------");
			System.out.println("Pulse enter para continuar");
			try {
				System.in.read();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		} while (opcionSeleccionada != 0);
		
		in.close();
	}

	private static void mostrarMenu() {
		System.out.println("Menu");
		System.out.println("----");
		System.out.println("1. Mostrar información de la base de datos");
		System.out.println("2. Mostrar resolución de ejercicios del 1 al 15");
		System.out.println("0. Salir");
		System.out.println("----");
		System.out.println("Elija la opción a ejecutar: ");
	}

}
