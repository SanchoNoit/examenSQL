package es.mde;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class EjercicioConexion {
	private String url, usuario, contrasena;
	Connection conexion = null;
	Statement sentencia = null;
	ResultSet resultado = null;

	public EjercicioConexion(String url, String usuario, String contrasena) {
		this.url = url;
		this.usuario = usuario;
		this.contrasena = contrasena;

		sentencia = conectar();
	}

	private Statement conectar() {
		java.sql.Statement sentencia = null;

		try {
			// 1. Primero, cargamos el driver para MySQL que hemos cargado mediante la
			// librería mysql-connector
			Class.forName("com.mysql.cj.jdbc.Driver");

			// 2. Segundo, establecemos una conexión al servidor.
			conexion = DriverManager.getConnection(url, usuario, contrasena);

			// 3. A continuación creamos el objeto Statement, que nos permitirá ejecutar
			// consultas SQL
			sentencia = conexion.createStatement();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sentencia = null;
		}
		
		return sentencia;
		
	}

	public String getUrl() {
		return url;
	}

	public String getUsuario() {
		return usuario;
	}

	public String getContrasena() {
		return contrasena;
	}

}
