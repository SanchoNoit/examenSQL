package es.mde;

import java.sql.SQLException;

public class InformacionServidor extends EjercicioConexion {

	public InformacionServidor(String url, String usuario, String contrasena) {
		super(url, usuario, contrasena);

		if (sentencia != null) {
			mostrarInformacionBBDD();
		}
	}

	private void mostrarInformacionBBDD() {
		System.out.println("Información básica del servidor: ");
		System.out.println("--------------------------------");

		try {

			// Version del servidor
			resultado = sentencia.executeQuery("SELECT VERSION()");
			// Mostrar los resultados1
			if (resultado.next()) {
				String version = resultado.getString(1);
				System.out.println("Versión del servidor MySQL: " + version);
			}

			// Versión MySQL
			resultado = sentencia.executeQuery("SHOW VARIABLES LIKE 'version'");
			// Mostrar los resultados
			if (resultado.next()) {
				String info = resultado.getString(2);
				System.out.println("Versión de MySQL: " + info);
			}

			// S.O
			resultado = sentencia.executeQuery("SHOW VARIABLES LIKE 'version_compile_os'");
			// Mostrar los resultados
			if (resultado.next()) {
				String info = resultado.getString(2);
				System.out.println("Sistema operativo: " + info);
			}
			
			System.out.println();
			
            // Cerrar la conexión y los recursos
            resultado.close();
            sentencia.close();
            conexion.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
