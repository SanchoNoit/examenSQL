package es.mde;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.google.common.collect.Streams;

public class ConsultasEjercicios extends EjercicioConexion {

	public ConsultasEjercicios(String url, String usuario, String contrasena) {
		super(url, usuario, contrasena);

		if (sentencia != null) {
			mostrarEjercicios();
		}
	}

	private void mostrarEjercicios() {
		System.out.println();

		// Emplear la BBDD 'sanchezVentas'
		try {
			sentencia.execute("USE sanchezVentas");
			System.out.println("0. Accedido a 'sanchezVentas', definida como BBDD para el ejercicio.");
			System.out.println();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		String[] arrayDeQuerieStrings = { "SELECT * FROM Empleados",
		                                  "SELECT NombreCompania, NombreContacto, Telefono FROM Proveedores",
		                                  "SELECT NombreProducto AS Nombre, CantidadPorUnidad AS UnidadesPorCaja, PrecioUnidad AS Precio, UnidadesEnExistencia AS Stock\n"
		                                  + "FROM Productos",
		                                  "SELECT DISTINCT Pais FROM Clientes",
		                                  "SELECT DISTINCT Pais, NombreContacto FROM Clientes",
		                                  "SELECT NombreCompania, Ciudad FROM Clientes WHERE Pais='Espana'",
		                                  "SELECT NombreCompania, NombreContacto, Ciudad, Telefono, Fax "
		                                  + "FROM Proveedores "
		                                  + "WHERE Pais = 'Estados Unidos' AND Ciudad = 'New Orleans'",
		                                  "SELECT NombreContacto, NombreCompania, Pais, Ciudad, Telefono "
		                                  + "FROM Clientes "
		                                  + "WHERE Pais IN ('Francia', 'Reino Unido')",
		                                  "SELECT Destinatario, DireccionDestinatario, PaisDestinatario "
		                                  + "FROM Pedidos "
		                                  + "WHERE PaisDestinatario NOT IN ('Estados Unidos', 'Alemania')"
		                                  };
		
		for (int i = 0; i < arrayDeQuerieStrings.length; i++) {
			System.out.println();
			System.out.println("Ejercicio n." + (i + 1));
			mostrarQuery(arrayDeQuerieStrings[i]);
			System.out.println();
		}
					

		// Cerrar la conexión y los recursos
		try {
			resultado.close();
			sentencia.close();
			conexion.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	private void mostrarQuery(String queryPasado) {
		try {

			resultado = sentencia.executeQuery(queryPasado);

			// Empleamos metadatos para saber cuantas columnas hay
			ResultSetMetaData metaData = resultado.getMetaData();
			int numColumnas = metaData.getColumnCount();
			
			// Después imprimimos los encabezados de columna
			for (int i = 1; i <= numColumnas; i++) {
				System.out.print(metaData.getColumnName(i) + "\t");
			}
			
            System.out.println("\n---------------------------------------------------");
            
            // Imprimimos los datos fila a fila
            while (resultado.next()) {
            	for (int i = 1; i <= numColumnas; i++ ) {
            		System.out.print(resultado.getString(i) + "\t");
            	}
            	System.out.println();
            }

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
